lst = ["st1","st2","st2"]
lst = "\n".join(lst)
print(lst)